"""
SciencePal SDK - Agent业务逻辑层

提供Agent的高级抽象,封装CRUD操作和便捷方法。
"""

from .api.agents import AgentsAPIClient
from .models import AgentCreateRequest, AgentResponse, AgentUpdateRequest, PaginationInfo


class Agent:
    """Agent对象封装

    代表一个SciencePal Agent实例,提供属性访问和更新方法。
    """

    def __init__(self, response: AgentResponse, client: AgentsAPIClient):
        """初始化Agent对象

        Args:
            response: Agent API响应数据
            client: Agent API客户端(用于更新操作)
        """
        self._response = response
        self._client = client

    # ==================== 属性访问 ====================

    @property
    def id(self) -> str:
        """Agent唯一标识符"""
        return self._response.agent_id

    @property
    def name(self) -> str:
        """Agent名称"""
        return self._response.name

    @property
    def account_id(self) -> str:
        """所属账号ID"""
        return self._response.account_id

    @property
    def description(self) -> str | None:
        """Agent描述"""
        return self._response.description

    @property
    def system_prompt(self) -> str:
        """系统提示词"""
        return self._response.system_prompt

    @property
    def configured_mcps(self) -> list[dict]:
        """MCP工具配置"""
        return self._response.configured_mcps

    @property
    def custom_mcps(self) -> list[dict]:
        """自定义MCP工具配置"""
        return self._response.custom_mcps

    @property
    def agentpress_tools(self) -> dict:
        """AgentPress工具配置"""
        return self._response.agentpress_tools

    @property
    def is_default(self) -> bool:
        """是否默认Agent"""
        return self._response.is_default

    @property
    def is_public(self) -> bool | None:
        """是否公开"""
        return self._response.is_public

    @property
    def avatar(self) -> str | None:
        """头像"""
        return self._response.avatar

    @property
    def avatar_color(self) -> str | None:
        """头像颜色"""
        return self._response.avatar_color

    @property
    def created_at(self):
        """创建时间"""
        return self._response.created_at

    @property
    def updated_at(self):
        """更新时间"""
        return self._response.updated_at

    # ==================== 更新方法 ====================

    async def update(
        self,
        name: str | None = None,
        description: str | None = None,
        system_prompt: str | None = None,
        configured_mcps: list[dict] | None = None,
        custom_mcps: list[dict] | None = None,
        agentpress_tools: dict | None = None,
        is_default: bool | None = None,
        avatar: str | None = None,
        avatar_color: str | None = None,
    ) -> "Agent":
        """更新Agent信息

        Args:
            name: 新的Agent名称
            description: 新的描述
            system_prompt: 新的系统提示词
            configured_mcps: MCP工具配置
            custom_mcps: 自定义MCP工具配置
            agentpress_tools: AgentPress工具配置
            is_default: 是否默认Agent
            avatar: 头像
            avatar_color: 头像颜色

        Returns:
            更新后的Agent对象(self)
        """
        request = AgentUpdateRequest(
            name=name,
            description=description,
            system_prompt=system_prompt,
            configured_mcps=configured_mcps,
            custom_mcps=custom_mcps,
            agentpress_tools=agentpress_tools,
            is_default=is_default,
            avatar=avatar,
            avatar_color=avatar_color,
        )

        updated_response = await self._client.update(self.id, request)
        self._response = updated_response
        return self

    async def delete(self) -> bool:
        """删除当前Agent

        Returns:
            True表示删除成功
        """
        return await self._client.delete(self.id)

    async def reload(self) -> "Agent":
        """重新加载Agent信息

        从API获取最新的Agent数据并更新本地状态。

        Returns:
            更新后的Agent对象(self)
        """
        updated_response = await self._client.get(self.id)
        self._response = updated_response
        return self

    def __repr__(self) -> str:
        """字符串表示"""
        return f"Agent(id={self.id}, name={self.name})"


class AgentManager:
    """Agent管理器

    提供Agent的创建、查询、列表等高级操作。
    """

    def __init__(self, client: AgentsAPIClient):
        """初始化Agent管理器

        Args:
            client: Agent API客户端
        """
        self._client = client

    async def create(
        self,
        name: str,
        system_prompt: str,
        description: str | None = None,
        configured_mcps: list[dict] | None = None,
        custom_mcps: list[dict] | None = None,
        agentpress_tools: dict | None = None,
        is_default: bool | None = None,
        avatar: str | None = None,
        avatar_color: str | None = None,
    ) -> Agent:
        """创建新Agent

        Args:
            name: Agent名称
            description: Agent描述
            system_prompt: 系统提示词
            configured_mcps: MCP工具配置
            custom_mcps: 自定义MCP工具配置
            agentpress_tools: AgentPress工具配置
            is_default: 是否默认Agent
            avatar: 头像
            avatar_color: 头像颜色

        Returns:
            创建的Agent对象

        Example:
            ```python
            agent = await manager.create(
                name="我的材料科学Agent",
                system_prompt="你是材料科学助手",
                description="专门用于晶体结构分析"
            )
            ```
        """
        request = AgentCreateRequest(
            name=name,
            system_prompt=system_prompt,
            description=description,
            configured_mcps=configured_mcps,
            custom_mcps=custom_mcps,
            agentpress_tools=agentpress_tools,
            is_default=is_default,
            avatar=avatar,
            avatar_color=avatar_color,
        )

        response = await self._client.create(request)
        return Agent(response, self._client)

    async def get(self, agent_id: str) -> Agent:
        """获取单个Agent

        Args:
            agent_id: Agent ID

        Returns:
            Agent对象

        Raises:
            AgentNotFoundError: Agent不存在
        """
        response = await self._client.get(agent_id)
        return Agent(response, self._client)

    async def list(
        self,
        page: int = 1,
        limit: int = 20,
        search: str | None = None,
        sort_by: str | None = None,
        sort_order: str | None = None,
        has_default: bool | None = None,
        has_mcp_tools: bool | None = None,
        has_agentpress_tools: bool | None = None,
        tools: str | None = None,
    ) -> tuple[list[Agent], PaginationInfo]:
        """获取Agent列表(含分页)

        Returns:
            (agents, pagination)
        """
        response = await self._client.list(
            page=page,
            limit=limit,
            search=search,
            sort_by=sort_by,
            sort_order=sort_order,
            has_default=has_default,
            has_mcp_tools=has_mcp_tools,
            has_agentpress_tools=has_agentpress_tools,
            tools=tools,
        )
        agents = [Agent(agent_data, self._client) for agent_data in response.agents]
        return agents, response.pagination

    async def delete(self, agent_id: str) -> bool:
        """删除Agent

        Args:
            agent_id: 要删除的Agent ID

        Returns:
            True表示删除成功
        """
        return await self._client.delete(agent_id)
