"""
SciencePal SDK 自定义异常

定义SDK中使用的所有异常类型,用于错误处理和异常传播。
"""


class SciencePalError(Exception):
    """SDK基础异常类"""

    def __init__(self, message: str, details: dict | None = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)

    def __str__(self) -> str:
        if self.details:
            return f"{self.message} (详情: {self.details})"
        return self.message


class AuthenticationError(SciencePalError):
    """认证失败异常

    当访问令牌无效或认证失败时抛出。
    """

    def __init__(self, message: str = "认证失败: 访问令牌无效或已过期"):
        super().__init__(message)


class AgentNotFoundError(SciencePalError):
    """Agent不存在异常

    当请求的Agent ID不存在时抛出。
    """

    def __init__(self, agent_id: str):
        message = f"Agent不存在: {agent_id}"
        super().__init__(message, details={"agent_id": agent_id})


class APIError(SciencePalError):
    """API调用异常

    当API请求失败时抛出,包含HTTP状态码和错误信息。
    """

    def __init__(
        self, status_code: int, message: str, response_body: dict | None = None
    ):
        self.status_code = status_code
        self.response_body = response_body or {}

        error_message = f"API错误 [{status_code}]: {message}"
        super().__init__(
            error_message,
            details={"status_code": status_code, "response_body": self.response_body},
        )


class NetworkError(SciencePalError):
    """网络连接异常

    当网络请求失败(超时、连接错误等)时抛出。
    """

    def __init__(self, message: str = "网络连接失败"):
        super().__init__(message)


class ValidationError(SciencePalError):
    """数据验证异常

    当输入数据不符合要求时抛出。
    """

    def __init__(self, field: str, message: str):
        error_message = f"验证错误 [{field}]: {message}"
        super().__init__(error_message, details={"field": field})


class StreamingError(SciencePalError):
    """流式响应异常

    当流式响应处理失败时抛出。
    """

    def __init__(self, message: str = "流式响应处理失败"):
        super().__init__(message)


class SandboxError(SciencePalError):
    """Sandbox操作异常

    当Sandbox文件或命令操作失败时抛出。
    """

    def __init__(self, operation: str, message: str):
        error_message = f"Sandbox操作失败 [{operation}]: {message}"
        super().__init__(error_message, details={"operation": operation})


class RateLimitError(APIError):
    """API速率限制异常

    当超过API调用速率限制时抛出。
    """

    def __init__(self, retry_after: int | None = None):
        message = "API调用速率限制"
        if retry_after:
            message += f", 请在{retry_after}秒后重试"

        super().__init__(429, message, {"retry_after": retry_after})
        self.retry_after = retry_after


class SDKTimeoutError(SciencePalError):
    """操作超时异常

    当操作超过指定时间限制时抛出。
    """

    def __init__(self, operation: str, timeout: int):
        message = f"操作超时: {operation} (超时设置: {timeout}秒)"
        super().__init__(message, details={"operation": operation, "timeout": timeout})
