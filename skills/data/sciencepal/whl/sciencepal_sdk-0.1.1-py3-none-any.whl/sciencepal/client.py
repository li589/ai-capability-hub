"""
SciencePal SDK - 主客户端
"""

from .agent import AgentManager
from .api.agent_runs import AgentRunsAPIClient
from .api.agents import AgentsAPIClient
from .api.sandbox import SandboxAPIClient
from .utils.constants import DEFAULT_BASE_URL, DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT


class SciencePal:
    """SciencePal SDK 主客户端

    仅对齐当前后端已提供的Agent、AgentRun与Sandbox接口。
    """

    def __init__(
        self,
        access_token: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        """初始化SciencePal客户端

        Args:
            access_token: Supabase JWT访问令牌
            base_url: API基础URL(默认包含/api前缀)
            timeout: 请求超时时间(秒)
            max_retries: 最大重试次数
        """
        self.access_token = access_token
        self.base_url = base_url
        self.timeout = timeout
        self.max_retries = max_retries

        self._agents_api = AgentsAPIClient(
            base_url=base_url,
            access_token=access_token,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._runs_api = AgentRunsAPIClient(
            base_url=base_url,
            access_token=access_token,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._sandbox_api = SandboxAPIClient(
            base_url=base_url,
            access_token=access_token,
            timeout=timeout,
            max_retries=max_retries,
        )

        self.agents = AgentManager(self._agents_api)
        self.runs = self._runs_api
        self.sandbox = self._sandbox_api

    async def close(self):
        """关闭所有HTTP客户端连接"""
        await self._agents_api.close()
        await self._runs_api.close()
        await self._sandbox_api.close()

    async def __aenter__(self):
        """异步上下文管理器入口"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器退出"""
        await self.close()

    def __repr__(self) -> str:
        return f"SciencePal(base_url={self.base_url})"
