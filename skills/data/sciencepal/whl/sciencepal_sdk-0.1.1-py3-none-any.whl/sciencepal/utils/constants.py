"""
SciencePal SDK 常量定义
"""

import os


def _get_int_env(name: str, default: int) -> int:
    value = os.getenv(name)
    if not value:
        return default
    try:
        return int(value)
    except ValueError:
        return default


# 默认配置(支持从环境变量覆盖)
DEFAULT_BASE_URL = os.getenv("SCIENCEPAL_BASE_URL", "https://api.sciencepal.ai/api")
DEFAULT_TIMEOUT = _get_int_env("REQUEST_TIMEOUT", 30)
DEFAULT_MAX_RETRIES = _get_int_env("MAX_RETRIES", 3)
