"""
SciencePal SDK 流式响应处理

处理Server-Sent Events (SSE) 流式响应。
"""

import json
from collections.abc import AsyncIterator

import httpx

from ..exceptions import StreamingError
from ..models import StreamEvent


async def parse_sse_stream(response: httpx.Response) -> AsyncIterator[StreamEvent]:
    """解析Server-Sent Events流

    Args:
        response: httpx响应对象(流式)

    Yields:
        StreamEvent对象

    Raises:
        StreamingError: 流式解析失败
    """
    try:
        async for line in response.aiter_lines():
            # 跳过空行
            if not line.strip():
                continue

            # SSE格式: "data: {json}"
            if line.startswith("data: "):
                data_str = line[6:]  # 去掉 "data: " 前缀

                # 特殊标记: [DONE]
                if data_str.strip() == "[DONE]":
                    yield StreamEvent(type="done")
                    break

                try:
                    # 解析JSON
                    data = json.loads(data_str)

                    event = StreamEvent(**data)
                    yield event

                    if event.type in ("done", "error"):
                        break

                except json.JSONDecodeError as e:
                    raise StreamingError(f"JSON解析失败: {str(e)}") from e

    except httpx.HTTPError as e:
        raise StreamingError(f"HTTP流式读取失败: {str(e)}") from e

    except Exception as e:
        raise StreamingError(f"未知流式错误: {str(e)}") from e


async def stream_to_text(stream: AsyncIterator[StreamEvent]) -> AsyncIterator[str]:
    """将StreamChunk流转换为纯文本流

    仅提取type=message的content内容。

    Args:
        stream: StreamChunk异步迭代器

    Yields:
        文本内容
    """
    async for event in stream:
        if event.type == "message" and event.content:
            yield event.content
        elif event.type == "error":
            raise StreamingError(event.message or "未知流式错误")


async def collect_stream(stream: AsyncIterator[StreamEvent]) -> str:
    """收集完整流式响应

    Args:
        stream: StreamChunk异步迭代器

    Returns:
        完整文本内容
    """
    content_parts = []

    async for event in stream:
        if event.type == "message" and event.content:
            content_parts.append(event.content)
        elif event.type == "error":
            raise StreamingError(event.message or "未知流式错误")

    return "".join(content_parts)
