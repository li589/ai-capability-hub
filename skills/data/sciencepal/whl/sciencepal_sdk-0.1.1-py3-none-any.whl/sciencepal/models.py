"""
SciencePal SDK 数据模型
"""

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


# ==================== 通用响应模型 ====================


class PaginationInfo(BaseModel):
    """分页信息"""

    page: int = Field(..., description="当前页码(1-based)")
    limit: int = Field(..., description="每页数量")
    total: int = Field(..., description="总数量")
    pages: int = Field(..., description="总页数")


# ==================== Agent 相关模型 ====================


class AgentCreateRequest(BaseModel):
    """创建Agent请求"""

    name: str = Field(..., description="Agent名称")
    system_prompt: str = Field(..., description="系统提示词")
    description: str | None = Field(None, description="Agent描述")
    configured_mcps: list[dict[str, Any]] | None = Field(
        default=None, description="MCP工具配置"
    )
    custom_mcps: list[dict[str, Any]] | None = Field(
        default=None, description="自定义MCP工具配置"
    )
    agentpress_tools: dict[str, Any] | None = Field(
        default=None, description="AgentPress工具配置"
    )
    is_default: bool | None = Field(default=None, description="是否默认Agent")
    avatar: str | None = Field(default=None, description="头像")
    avatar_color: str | None = Field(default=None, description="头像颜色")


class AgentUpdateRequest(BaseModel):
    """更新Agent请求"""

    name: str | None = Field(None, description="新的Agent名称")
    description: str | None = Field(None, description="新的描述")
    system_prompt: str | None = Field(None, description="新的系统提示词")
    configured_mcps: list[dict[str, Any]] | None = Field(
        default=None, description="MCP工具配置"
    )
    custom_mcps: list[dict[str, Any]] | None = Field(
        default=None, description="自定义MCP工具配置"
    )
    agentpress_tools: dict[str, Any] | None = Field(
        default=None, description="AgentPress工具配置"
    )
    is_default: bool | None = Field(default=None, description="是否默认Agent")
    avatar: str | None = Field(default=None, description="头像")
    avatar_color: str | None = Field(default=None, description="头像颜色")


class AgentResponse(BaseModel):
    """Agent响应模型"""

    agent_id: str = Field(..., description="Agent唯一标识符")
    account_id: str = Field(..., description="所属账号ID")
    name: str = Field(..., description="Agent名称")
    description: str | None = Field(None, description="Agent描述")
    system_prompt: str = Field(..., description="系统提示词")
    configured_mcps: list[dict[str, Any]] = Field(
        default_factory=list, description="MCP工具配置"
    )
    custom_mcps: list[dict[str, Any]] = Field(
        default_factory=list, description="自定义MCP工具配置"
    )
    agentpress_tools: dict[str, Any] = Field(
        default_factory=dict, description="AgentPress工具配置"
    )
    is_default: bool = Field(default=False, description="是否默认Agent")
    is_public: bool | None = Field(default=False, description="是否公开")
    marketplace_published_at: str | None = Field(
        default=None, description="上架时间"
    )
    download_count: int | None = Field(default=0, description="下载次数")
    tags: list[str] | None = Field(default_factory=list, description="标签")
    avatar: str | None = Field(default=None, description="头像")
    avatar_color: str | None = Field(default=None, description="头像颜色")
    created_at: str = Field(..., description="创建时间")
    updated_at: str = Field(..., description="更新时间")


class AgentsResponse(BaseModel):
    """Agent列表响应"""

    agents: list[AgentResponse] = Field(default_factory=list)
    pagination: PaginationInfo


# ==================== Agent Run 相关模型 ====================


class AgentStartRequest(BaseModel):
    """启动Agent请求"""

    model_name: str | None = Field(None, description="模型名称")
    enable_thinking: bool | None = Field(default=False, description="启用思考模式")
    reasoning_effort: Literal["low", "medium", "high"] | None = Field(
        default="low", description="推理强度"
    )
    stream: bool | None = Field(default=True, description="是否流式响应")
    enable_context_manager: bool | None = Field(
        default=False, description="启用上下文管理器"
    )
    agent_id: str | None = Field(None, description="自定义Agent ID")
    dataset_ids: list[str] | None = Field(None, description="知识库数据集ID列表")
    kb_api_key: str | None = Field(None, description="知识库API密钥")
    kb_url: str | None = Field(None, description="知识库URL")
    web_search_on: bool | None = Field(default=True, description="启用网络搜索")


class AgentRunStartResponse(BaseModel):
    """Agent启动响应"""

    agent_run_id: str = Field(..., description="Run ID")
    status: str = Field(..., description="运行状态")


class InitiateAgentResponse(BaseModel):
    """发起新会话响应"""

    thread_id: str = Field(..., description="Thread ID")
    agent_run_id: str | None = Field(default=None, description="Run ID")


class AgentRunStatus(BaseModel):
    """Agent运行状态"""

    model_config = ConfigDict(populate_by_name=True)

    id: str = Field(..., description="Run ID")
    thread_id: str | None = Field(default=None, alias="threadId")
    status: str | None = Field(default=None, description="运行状态")
    started_at: str | None = Field(default=None, alias="startedAt")
    completed_at: str | None = Field(default=None, alias="completedAt")
    error: str | None = Field(default=None, description="错误信息")


class AgentRunRecord(BaseModel):
    """Agent运行记录(列表)"""

    model_config = ConfigDict(extra="allow")

    id: str | None = Field(default=None)
    thread_id: str | None = Field(default=None)
    status: str | None = Field(default=None)
    started_at: str | None = Field(default=None)
    completed_at: str | None = Field(default=None)
    error: str | None = Field(default=None)


class ThreadAgentResponse(BaseModel):
    """Thread关联Agent响应"""

    agent: AgentResponse | None = Field(default=None, description="Agent信息")
    source: str = Field(..., description="来源(thread/default/none/missing)")
    message: str = Field(..., description="提示信息")


class StreamEvent(BaseModel):
    """SSE流式事件"""

    model_config = ConfigDict(extra="allow")

    type: str | None = Field(default=None, description="事件类型")
    status: str | None = Field(default=None, description="状态")
    content: str | None = Field(default=None, description="内容")
    message: str | None = Field(default=None, description="消息")
    metadata: Any | None = Field(default=None, description="元数据")
    created_at: datetime | None = Field(default=None, description="创建时间")
    updated_at: datetime | None = Field(default=None, description="更新时间")
    thread_id: str | None = Field(default=None, description="Thread ID")
    message_id: str | None = Field(default=None, description="消息ID")
    is_llm_message: bool | None = Field(default=None, description="是否LLM消息")


# ==================== Sandbox 相关模型 ====================


class FileInfo(BaseModel):
    """文件信息"""

    name: str = Field(..., description="文件名")
    path: str = Field(..., description="文件路径")
    is_dir: bool = Field(..., description="是否为目录")
    size: int = Field(..., description="文件大小(字节)")
    mod_time: str = Field(..., description="修改时间")
    permissions: str | None = Field(None, description="权限")


class SandboxUrlInfo(BaseModel):
    """Sandbox URL信息"""

    vnc_preview: str | None = Field(None, description="VNC预览URL")
    sandbox_url: str | None = Field(None, description="Sandbox URL")


class ThreadSandboxInfo(BaseModel):
    """Thread对应的Sandbox信息"""

    thread_id: str = Field(..., description="Thread ID")
    project_id: str = Field(..., description="Project ID")
    sandbox_id: str = Field(..., description="Sandbox ID")
    sandbox_info: SandboxUrlInfo = Field(..., description="Sandbox URL信息")
