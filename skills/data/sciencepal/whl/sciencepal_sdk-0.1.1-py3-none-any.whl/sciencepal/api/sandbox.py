"""
SciencePal SDK - Sandbox API客户端

提供Sandbox环境的文件操作功能。
"""

from ..models import FileInfo, ThreadSandboxInfo
from .base import BaseAPIClient


class SandboxAPIClient(BaseAPIClient):
    """Sandbox操作API客户端"""

    async def read_file(self, sandbox_id: str, file_path: str) -> bytes:
        """读取Sandbox文件内容"""
        response = await self._get(
            f"/sandboxes/{sandbox_id}/files/content",
            params={"path": file_path},
        )
        return response.content

    async def write_file(
        self, sandbox_id: str, file_path: str, content: bytes | str
    ) -> bool:
        """写入Sandbox文件"""
        if isinstance(content, str):
            content = content.encode("utf-8")
        files = {
            "file": (file_path.split("/")[-1], content, "application/octet-stream")
        }
        data = {"path": file_path}

        await self._post(
            f"/sandboxes/{sandbox_id}/files",
            json_data=None,
            data=data,
            files=files,
        )
        return True

    async def delete_file(self, sandbox_id: str, file_path: str) -> bool:
        """删除Sandbox文件"""
        await self._delete(
            f"/sandboxes/{sandbox_id}/files",
            params={"path": file_path},
        )
        return True

    async def list_files(self, sandbox_id: str, directory: str = "/") -> list[FileInfo]:
        """列出Sandbox目录内容"""
        response = await self._get(
            f"/sandboxes/{sandbox_id}/files",
            params={"path": directory},
        )
        files_data = response.json()
        if isinstance(files_data, dict) and "files" in files_data:
            return [FileInfo(**file) for file in files_data["files"]]
        return [FileInfo(**file) for file in files_data]

    async def delete_sandbox(self, sandbox_id: str) -> bool:
        """删除Sandbox"""
        await self._delete(f"/sandboxes/{sandbox_id}")
        return True

    async def get_thread_sandbox(self, thread_id: str) -> ThreadSandboxInfo:
        """获取Thread对应的Sandbox信息

        Args:
            thread_id: Thread ID

        Returns:
            ThreadSandboxInfo: 包含 thread_id, project_id, sandbox_id, sandbox_info 的对象
        """
        response = await self._get(f"/thread/{thread_id}/sandbox")
        return ThreadSandboxInfo(**response.json())

    async def download_file(self, thread_id: str, file_path: str) -> bytes:
        """通过thread_id下载Sandbox中的文件

        Args:
            thread_id: Thread ID
            file_path: 文件路径

        Returns:
            bytes: 文件内容
        """
        sandbox_info = await self.get_thread_sandbox(thread_id)
        return await self.read_file(sandbox_info.sandbox_id, file_path)
