"""
SciencePal SDK - Agent API客户端

提供Agent的CRUD操作功能,包括创建、查询、更新和删除Agent。
"""

from ..models import (
    AgentCreateRequest,
    AgentResponse,
    AgentsResponse,
    AgentUpdateRequest,
    PaginationInfo,
)
from .base import BaseAPIClient


class AgentsAPIClient(BaseAPIClient):
    """Agent管理API客户端"""

    async def create(self, request: AgentCreateRequest) -> AgentResponse:
        """创建新Agent"""
        response = await self._post(
            "/agents", json_data=request.model_dump(exclude_none=True)
        )
        return AgentResponse(**response.json())

    async def get(self, agent_id: str) -> AgentResponse:
        """获取单个Agent详情"""
        response = await self._get(f"/agents/{agent_id}")
        return AgentResponse(**response.json())

    async def list(
        self,
        page: int = 1,
        limit: int = 20,
        search: str | None = None,
        sort_by: str | None = None,
        sort_order: str | None = None,
        has_default: bool | None = None,
        has_mcp_tools: bool | None = None,
        has_agentpress_tools: bool | None = None,
        tools: str | None = None,
    ) -> AgentsResponse:
        """获取Agent列表(含分页)"""
        params: dict[str, str | int | bool] = {"page": page, "limit": limit}
        if search:
            params["search"] = search
        if sort_by:
            params["sort_by"] = sort_by
        if sort_order:
            params["sort_order"] = sort_order
        if has_default is not None:
            params["has_default"] = has_default
        if has_mcp_tools is not None:
            params["has_mcp_tools"] = has_mcp_tools
        if has_agentpress_tools is not None:
            params["has_agentpress_tools"] = has_agentpress_tools
        if tools:
            params["tools"] = tools

        response = await self._get("/agents", params=params)
        agents_data = response.json()

        if isinstance(agents_data, dict) and "agents" in agents_data:
            pagination = agents_data.get("pagination") or {}
            return AgentsResponse(
                agents=[AgentResponse(**agent) for agent in agents_data["agents"]],
                pagination=PaginationInfo(**pagination),
            )

        return AgentsResponse(
            agents=[AgentResponse(**agent) for agent in agents_data],
            pagination=PaginationInfo(
                page=page, limit=limit, total=len(agents_data), pages=1
            ),
        )

    async def update(self, agent_id: str, request: AgentUpdateRequest) -> AgentResponse:
        """更新Agent信息"""
        response = await self._put(
            f"/agents/{agent_id}",
            json_data=request.model_dump(exclude_none=True),
        )
        return AgentResponse(**response.json())

    async def delete(self, agent_id: str) -> bool:
        """删除Agent"""
        await self._delete(f"/agents/{agent_id}")
        return True
