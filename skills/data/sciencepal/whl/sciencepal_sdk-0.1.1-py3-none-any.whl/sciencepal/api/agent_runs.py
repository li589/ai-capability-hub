"""
SciencePal SDK - Agent Run API客户端

提供Agent运行的发起、查询、流式读取等能力。
"""

import json
from collections.abc import AsyncIterator

import httpx

from ..models import (
    AgentRunRecord,
    AgentRunStartResponse,
    AgentRunStatus,
    AgentStartRequest,
    InitiateAgentResponse,
    StreamEvent,
    ThreadAgentResponse,
)
from ..utils.streaming import parse_sse_stream
from .base import BaseAPIClient


class AgentRunsAPIClient(BaseAPIClient):
    """Agent Run管理API客户端"""

    async def start(
        self, thread_id: str, request: AgentStartRequest
    ) -> AgentRunStartResponse:
        """为指定Thread启动Agent"""
        response = await self._post(
            f"/thread/{thread_id}/agent/start",
            json_data=request.model_dump(exclude_none=True),
        )
        return AgentRunStartResponse(**response.json())

    async def initiate(
        self,
        prompt: str,
        *,
        model_name: str | None = None,
        enable_thinking: bool = False,
        reasoning_effort: str = "low",
        stream: bool = True,
        enable_context_manager: bool = False,
        agent_id: str | None = None,
        files: list[tuple[str, bytes]] | None = None,
        is_agent_builder: bool = False,
        target_agent_id: str | None = None,
        dataset_ids: list[str] | None = None,
        kb_api_key: str | None = None,
        kb_url: str | None = None,
        web_search_on: bool = True,
        agent_select_type: str = "manual",
    ) -> InitiateAgentResponse:
        """发起新Agent会话(支持文件上传)"""
        data: dict[str, str] = {
            "prompt": prompt,
            "enable_thinking": "true" if enable_thinking else "false",
            "reasoning_effort": reasoning_effort,
            "stream": "true" if stream else "false",
            "enable_context_manager": "true" if enable_context_manager else "false",
            "is_agent_builder": "true" if is_agent_builder else "false",
            "agent_select_type": agent_select_type,
            "web_search_on": "true" if web_search_on else "false",
        }
        if model_name:
            data["model_name"] = model_name
        if agent_id:
            data["agent_id"] = agent_id
        if target_agent_id:
            data["target_agent_id"] = target_agent_id
        if dataset_ids:
            data["dataset_ids"] = json.dumps(dataset_ids)
        if kb_api_key:
            data["kb_api_key"] = kb_api_key
        if kb_url:
            data["kb_url"] = kb_url

        upload_files = []
        if files:
            for filename, content in files:
                upload_files.append(
                    ("files", (filename, content, "application/octet-stream"))
                )

        response = await self._post(
            "/agent/initiate",
            json_data=None,
            data=data,
            files=upload_files or None,
        )
        return InitiateAgentResponse(**response.json())

    async def get(self, agent_run_id: str) -> AgentRunStatus:
        """获取Run状态"""
        response = await self._get(f"/agent-run/{agent_run_id}")
        return AgentRunStatus(**response.json())

    async def stop(self, agent_run_id: str) -> bool:
        """停止Run"""
        await self._post(f"/agent-run/{agent_run_id}/stop", json_data={})
        return True

    async def list_thread_runs(self, thread_id: str) -> list[AgentRunRecord]:
        """获取Thread的Run列表"""
        response = await self._get(f"/thread/{thread_id}/agent-runs")
        payload = response.json()
        runs = payload.get("agent_runs", []) if isinstance(payload, dict) else []
        return [AgentRunRecord(**run) for run in runs]

    async def get_thread_agent(self, thread_id: str) -> ThreadAgentResponse:
        """获取Thread关联的Agent"""
        response = await self._get(f"/thread/{thread_id}/agent")
        return ThreadAgentResponse(**response.json())

    async def stream(self, agent_run_id: str) -> AsyncIterator[StreamEvent]:
        """流式读取Run响应"""
        async with self._client.stream(
            method="GET",
            url=f"/agent-run/{agent_run_id}/stream",
            timeout=httpx.Timeout(timeout=300.0, connect=10.0),
        ) as response:
            if response.status_code != 200:
                from ..exceptions import APIError, AuthenticationError

                if response.status_code == 401:
                    raise AuthenticationError()
                try:
                    error_body = response.json()
                except Exception:
                    error_body = {}
                raise APIError(
                    status_code=response.status_code,
                    message=error_body.get("detail") or error_body.get("error") or response.text,
                    response_body=error_body,
                )

            async for event in parse_sse_stream(response):
                yield event
