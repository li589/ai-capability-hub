"""
SciencePal SDK API基础客户端

提供HTTP通信的基础能力,包括请求封装、错误处理、重试逻辑等。
"""

import asyncio
from typing import Any

import httpx

from ..exceptions import (
    APIError,
    AuthenticationError,
    NetworkError,
    RateLimitError,
    SDKTimeoutError,
)


class BaseAPIClient:
    """HTTP通信基类

    所有API客户端的基类,提供统一的HTTP请求方法和错误处理。
    """

    def __init__(
        self,
        base_url: str,
        access_token: str | None,
        timeout: int = 30,
        max_retries: int = 3,
    ):
        """初始化API客户端

        Args:
            base_url: API基础URL
            access_token: Supabase JWT访问令牌
            timeout: 请求超时时间(秒)
            max_retries: 最大重试次数
        """
        self.base_url = self._normalize_base_url(base_url)
        self.access_token = access_token
        self.timeout = timeout
        self.max_retries = max_retries

        from .. import __version__ as sdk_version

        headers = {
            "User-Agent": f"SciencePal-SDK/{sdk_version}",
            "Accept": "application/json",
        }
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"

        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=headers,
            timeout=httpx.Timeout(timeout),
        )

    @staticmethod
    def _normalize_base_url(base_url: str) -> str:
        normalized = base_url.rstrip("/")
        if not normalized.endswith("/api"):
            normalized = f"{normalized}/api"
        return normalized

    async def _request(
        self,
        method: str,
        endpoint: str,
        retry_count: int = 0,
        **kwargs,
    ) -> httpx.Response:
        """统一请求方法

        包含错误处理、重试逻辑和响应验证。

        Args:
            method: HTTP方法 (GET, POST, PATCH, DELETE)
            endpoint: API端点
            retry_count: 当前重试次数
            **kwargs: 传递给httpx的其他参数

        Returns:
            httpx.Response对象

        Raises:
            AuthenticationError: 认证失败
            RateLimitError: 速率限制
            APIError: API错误
            NetworkError: 网络错误
            SDKTimeoutError: 请求超时
        """
        try:
            # 发送请求
            response = await self._client.request(
                method=method,
                url=endpoint,
                **kwargs,
            )

            # 处理响应状态码
            if 200 <= response.status_code < 300:
                return response

            # 认证错误
            if response.status_code == 401:
                raise AuthenticationError()

            # 速率限制
            if response.status_code == 429:
                retry_after = response.headers.get("Retry-After")
                retry_after_int = int(retry_after) if retry_after else None
                raise RateLimitError(retry_after=retry_after_int)

            # 其他API错误
            try:
                error_body = response.json()
            except Exception:
                error_body = {}

            error_message = error_body.get("detail") or error_body.get("error")
            if isinstance(error_message, dict):
                error_message = error_message.get("message")
            if not error_message:
                error_message = error_body.get("message", response.text)
            raise APIError(
                status_code=response.status_code,
                message=error_message,
                response_body=error_body,
            )

        except httpx.TimeoutException as e:
            # 超时错误,可重试
            if retry_count < self.max_retries:
                await asyncio.sleep(2**retry_count)  # 指数退避
                return await self._request(
                    method, endpoint, retry_count=retry_count + 1, **kwargs
                )
            raise SDKTimeoutError(
                operation=f"{method} {endpoint}", timeout=self.timeout
            ) from e

        except httpx.NetworkError as e:
            # 网络错误,可重试
            if retry_count < self.max_retries:
                await asyncio.sleep(2**retry_count)
                return await self._request(
                    method, endpoint, retry_count=retry_count + 1, **kwargs
                )
            raise NetworkError(f"网络请求失败: {str(e)}") from e

        except (AuthenticationError, RateLimitError, APIError):
            # SDK自定义异常,直接抛出
            raise

        except Exception as e:
            # 未知异常
            raise NetworkError(f"未知错误: {str(e)}") from e

    async def _get(
        self,
        endpoint: str,
        params: dict[str, Any] | None = None,
        **kwargs,
    ) -> httpx.Response:
        """GET请求

        Args:
            endpoint: API端点
            params: 查询参数

        Returns:
            httpx.Response对象
        """
        return await self._request("GET", endpoint, params=params, **kwargs)

    async def _post(
        self,
        endpoint: str,
        json_data: dict[str, Any] | None = None,
        **kwargs,
    ) -> httpx.Response:
        """POST请求"""
        request_kwargs = dict(kwargs)
        if json_data is not None:
            request_kwargs["json"] = json_data
        return await self._request("POST", endpoint, **request_kwargs)

    async def _put(
        self,
        endpoint: str,
        json_data: dict[str, Any] | None = None,
        **kwargs,
    ) -> httpx.Response:
        """PUT请求"""
        request_kwargs = dict(kwargs)
        if json_data is not None:
            request_kwargs["json"] = json_data
        return await self._request("PUT", endpoint, **request_kwargs)

    async def _patch(
        self,
        endpoint: str,
        json_data: dict[str, Any] | None = None,
        **kwargs,
    ) -> httpx.Response:
        """PATCH请求"""
        request_kwargs = dict(kwargs)
        if json_data is not None:
            request_kwargs["json"] = json_data
        return await self._request("PATCH", endpoint, **request_kwargs)

    async def _delete(
        self,
        endpoint: str,
        **kwargs,
    ) -> httpx.Response:
        """DELETE请求

        Args:
            endpoint: API端点

        Returns:
            httpx.Response对象
        """
        return await self._request("DELETE", endpoint, **kwargs)

    async def close(self):
        """关闭HTTP客户端"""
        await self._client.aclose()

    async def __aenter__(self):
        """异步上下文管理器入口"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器退出"""
        await self.close()
