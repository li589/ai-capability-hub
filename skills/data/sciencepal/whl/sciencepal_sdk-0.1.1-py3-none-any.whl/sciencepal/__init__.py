"""
SciencePal SDK - Official Python SDK for SciencePal Platform

Quick Start:
    ```python
    import asyncio
    from sciencepal import SciencePal

    async def main():
        async with SciencePal(access_token="your-jwt-token") as client:
            response = await client.runs.initiate(prompt="你好")
            print(response.thread_id, response.agent_run_id)

    asyncio.run(main())
    ```
"""

from importlib.metadata import PackageNotFoundError, version

from .agent import Agent, AgentManager
from .client import SciencePal
from .exceptions import (
    AgentNotFoundError,
    APIError,
    AuthenticationError,
    NetworkError,
    RateLimitError,
    SandboxError,
    SciencePalError,
    SDKTimeoutError,
    StreamingError,
    ValidationError,
)
from .models import (
    AgentCreateRequest,
    AgentResponse,
    AgentRunRecord,
    AgentRunStartResponse,
    AgentRunStatus,
    AgentStartRequest,
    AgentsResponse,
    FileInfo,
    InitiateAgentResponse,
    PaginationInfo,
    StreamEvent,
    ThreadAgentResponse,
)

try:
    __version__ = version("sciencepal-sdk")
except PackageNotFoundError:
    __version__ = "0.1.0"

__all__ = [
    "SciencePal",
    "Agent",
    "AgentManager",
    "AgentCreateRequest",
    "AgentResponse",
    "AgentsResponse",
    "PaginationInfo",
    "AgentStartRequest",
    "AgentRunStartResponse",
    "InitiateAgentResponse",
    "AgentRunStatus",
    "AgentRunRecord",
    "StreamEvent",
    "ThreadAgentResponse",
    "FileInfo",
    "SciencePalError",
    "AuthenticationError",
    "AgentNotFoundError",
    "APIError",
    "NetworkError",
    "ValidationError",
    "StreamingError",
    "SandboxError",
    "RateLimitError",
    "SDKTimeoutError",
]
